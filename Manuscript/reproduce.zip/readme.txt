This document describes how to reproduce the analyses in the
COVIDNearTerm manuscript.  The file that runs the analyses is called
reproduce.R.  As input it takes three files:

1. hosp_matrix.txt -- True hospitalization rates from the six
counties being studied.  This file originally was downoaded from using
the command
fromJSON('https://data.chhs.ca.gov/api/3/action/datastore_search?resource_id=47af979d-8685-4981-bced-96a6b79d3ed5&limit=50000'),
but it was eventually saved to not require repeated downloading.

2. hist_hosp.csv -- Historical hospital predictions from CalCAT models
downloaded from the California Department of Public Health on May 11,
2021.  Here the variable "p_date" is the date when the prediction is
made and "est_date" is the date for which hospitalizations are being
predicted.

This file is too big for GitHub.  So you can get the required files
from the Manuscript directory of the COVIDNearTerm repository and
construct this file.  It requires the files firstline_hist_hosp.csv,
alameda_hist_hosp.csv, contracosta_hist_hosp.csv, marin_hist_hosp.csv,
sanfrancisco_hist_hosp.csv, sanmateo_hist_hosp.csv, and
santaclara_hist_hosp.csv.

Then run the command "cat firstline_hist_hosp.csv alameda_hist_hosp.csv contracosta_hist_hosp.csv marin_hist_hosp.csv sanfrancisco_hist_hosp.csv sanmateo_hist_hosp.csv santaclara_hist_hosp.csv > hist_hosp.csv"

3. shrinkage_[county]_hosp_pred.csv contains the hospitalization
predictions made by COVIDNearTerm.

The output from running reproduce.R should be figure1.pdf,
figure2.pdf, figure3.pdf and table2.txt, which are the figure and the
numerical table from the manuscript.  It should give
final_lower_percentage.all.txt and final_upper_percentage.all.txt,
which contain the 25th percentile and 75th percentile errors that are
used in the manuscript.  There are also other intermediate
calculations from the manuscript.



