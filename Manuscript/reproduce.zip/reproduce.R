###Reproduce all analyses in manuscript

###Figure 1 for paper, two weeks out, mutiple parameters

###Last day for making predictions is 2021-04-28
###Last day for two week predictions of 2021-05-12
###First day for making predictions is 2020-06-14
###First day for two week predictions is 2020-06-28

end.date <- as.Date("2021-05-01")
end.date.numeric <- as.numeric(end.date)
    
start.date <- as.Date("2020-06-28")
start.date.numeric <- as.numeric(start.date)
    
counties <- c("alameda","contracosta","marin","sanfrancisco","sanmateo","santaclara")
counties.labels <- c("Alameda","Contra Costa","Marin","San Francisco","San Mateo","Santa Clara")
n.counties <- length(counties)

dat <- vector("list",n.counties)
dat.equal.7 <- dat
dat.equal.14 <- dat
dat.equal.21 <- dat
dat.equal.28 <- dat
dat.equal.35 <- dat
dat.unweighted.7 <- dat
dat.unweighted.14 <- dat
dat.unweighted.21 <- dat
dat.unweighted.28 <- dat
dat.unweighted.35 <- dat
dat.triangle.7 <- dat
dat.triangle.14 <- dat
dat.triangle.21 <- dat
dat.triangle.28 <- dat
dat.triangle.35 <- dat
dat.unweighted <- dat
dat.triangle <- dat

for(i in 1:n.counties)
{
    dat[[i]] <- read.delim(paste0("shrinkage_",counties[i],"_hosp_pred.csv"),sep=",",header=TRUE,as.is=TRUE)
    dat[[i]] <- dat[[i]][order(dat[[i]]$"pred_startdt"),]
###Don't go past end date
    dat[[i]] <- dat[[i]][which(as.numeric(as.Date(dat[[i]]$Date))<=end.date.numeric),]
###Don't start before start date
    dat[[i]] <- dat[[i]][which(as.numeric(as.Date(dat[[i]]$Date))>=start.date.numeric),]    
###Focus on two weeks out
    dat[[i]] <- dat[[i]][which((as.numeric(as.Date(dat[[i]]$Date))-as.numeric(as.Date(dat[[i]]$"pred_startdt")))==13),]
    dat.equal.7[[i]] <- dat[[i]][which(dat[[i]]$method=="equal" & dat[[i]]$wsize=="7"),]
    dat.equal.14[[i]] <- dat[[i]][which(dat[[i]]$method=="equal" & dat[[i]]$wsize=="14"),]
    dat.equal.21[[i]] <- dat[[i]][which(dat[[i]]$method=="equal" & dat[[i]]$wsize=="21"),]
    dat.equal.28[[i]] <- dat[[i]][which(dat[[i]]$method=="equal" & dat[[i]]$wsize=="28"),]
    dat.equal.35[[i]] <- dat[[i]][which(dat[[i]]$method=="equal" & dat[[i]]$wsize=="35"),]
    dat.unweighted.7[[i]] <- dat[[i]][which(dat[[i]]$method=="unweighted" & dat[[i]]$wsize=="7"),]
    dat.unweighted.14[[i]] <- dat[[i]][which(dat[[i]]$method=="unweighted" & dat[[i]]$wsize=="14"),]
    dat.unweighted.21[[i]] <- dat[[i]][which(dat[[i]]$method=="unweighted" & dat[[i]]$wsize=="21"),]
    dat.unweighted.28[[i]] <- dat[[i]][which(dat[[i]]$method=="unweighted" & dat[[i]]$wsize=="28"),]
    dat.unweighted.35[[i]] <- dat[[i]][which(dat[[i]]$method=="unweighted" & dat[[i]]$wsize=="35"),]
    dat.triangle.7[[i]] <- dat[[i]][which(dat[[i]]$method=="triangle" & dat[[i]]$wsize=="7"),]
    dat.triangle.14[[i]] <- dat[[i]][which(dat[[i]]$method=="triangle" & dat[[i]]$wsize=="14"),]
    dat.triangle.21[[i]] <- dat[[i]][which(dat[[i]]$method=="triangle" & dat[[i]]$wsize=="21"),]
    dat.triangle.28[[i]] <- dat[[i]][which(dat[[i]]$method=="triangle" & dat[[i]]$wsize=="28"),]
    dat.triangle.35[[i]] <- dat[[i]][which(dat[[i]]$method=="triangle" & dat[[i]]$wsize=="35"),]
}

###Truth originally came from: fromJSON('https://data.chhs.ca.gov/api/3/action/datastore_search?resource_id=47af979d-8685-4981-bced-96a6b79d3ed5&limit=50000')
###So that there would be one fixed file it was saved into the file hosp_matrix.txt  

hosp.matrix <- read.delim("hosp_matrix.txt",header=TRUE,as.is=TRUE,sep="\t")
colnames(hosp.matrix) <- counties.labels

errors.dat.equal.7 <- dat.equal.7
errors.dat.equal.14 <- dat.equal.14
errors.dat.equal.21 <- dat.equal.21
errors.dat.equal.28 <- dat.equal.28
errors.dat.equal.35 <- dat.equal.35
errors.dat.unweighted.7 <- dat.unweighted.7
errors.dat.unweighted.14 <- dat.unweighted.14
errors.dat.unweighted.21 <- dat.unweighted.21
errors.dat.unweighted.28 <- dat.unweighted.28
errors.dat.unweighted.35 <- dat.unweighted.35
errors.dat.triangle.7 <- dat.triangle.7
errors.dat.triangle.14 <- dat.triangle.14
errors.dat.triangle.21 <- dat.triangle.21
errors.dat.triangle.28 <- dat.triangle.28
errors.dat.triangle.35 <- dat.triangle.35

for(i in 1:n.counties)
{
    errors.dat.equal.7[[i]] <- 100*(dat.equal.7[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.equal.14[[i]] <- 100*(dat.equal.14[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.equal.21[[i]] <- 100*(dat.equal.21[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.equal.28[[i]] <- 100*(dat.equal.28[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.equal.35[[i]] <- 100*(dat.equal.35[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.unweighted.7[[i]] <- 100*(dat.unweighted.7[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.unweighted.14[[i]] <- 100*(dat.unweighted.14[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.unweighted.21[[i]] <- 100*(dat.unweighted.21[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.unweighted.28[[i]] <- 100*(dat.unweighted.28[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.unweighted.35[[i]] <- 100*(dat.unweighted.35[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.triangle.7[[i]] <- 100*(dat.triangle.7[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.triangle.14[[i]] <- 100*(dat.triangle.14[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.triangle.21[[i]] <- 100*(dat.triangle.21[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.triangle.28[[i]] <- 100*(dat.triangle.28[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.dat.triangle.35[[i]] <- 100*(dat.triangle.35[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
}

###Santa Clara W=14 and unequal

sc.w14.median <- round(median(abs(errors.dat.unweighted.14[[6]])))
sc.w14.lower <- round(quantile(abs(errors.dat.unweighted.14[[6]]),0.25))
sc.w14.upper <- round(quantile(abs(errors.dat.unweighted.14[[6]]),0.75))

###San Francisco W=14 and unequal

sf.w14.median <- round(median(abs(errors.dat.unweighted.14[[4]])))
sf.w14.lower <- round(quantile(abs(errors.dat.unweighted.14[[4]]),0.25))
sf.w14.upper <- round(quantile(abs(errors.dat.unweighted.14[[4]]),0.75))

###Mean across counties

all.w14.median.mean.unweighted <- round(mean(c(median(abs(errors.dat.unweighted.14[[1]])),median(abs(errors.dat.unweighted.14[[2]])),median(abs(errors.dat.unweighted.14[[3]])),median(abs(errors.dat.unweighted.14[[4]])),median(abs(errors.dat.unweighted.14[[5]])),median(abs(errors.dat.unweighted.14[[6]])))),digits=1)
all.w14.lower.mean.unweighted <- round(mean(c(quantile(abs(errors.dat.unweighted.14[[1]]),0.25),quantile(abs(errors.dat.unweighted.14[[2]]),0.25),quantile(abs(errors.dat.unweighted.14[[3]]),0.25),quantile(abs(errors.dat.unweighted.14[[4]]),0.25),quantile(abs(errors.dat.unweighted.14[[5]]),0.25),quantile(abs(errors.dat.unweighted.14[[6]]),0.25))),1)
all.w14.upper.mean.unweighted <- round(mean(c(quantile(abs(errors.dat.unweighted.14[[1]]),0.75),quantile(abs(errors.dat.unweighted.14[[2]]),0.75),quantile(abs(errors.dat.unweighted.14[[3]]),0.75),quantile(abs(errors.dat.unweighted.14[[4]]),0.75),quantile(abs(errors.dat.unweighted.14[[5]]),0.75),quantile(abs(errors.dat.unweighted.14[[6]]),0.75))),1)

all.w14.median.mean.equal <- round(mean(c(median(abs(errors.dat.equal.14[[1]])),median(abs(errors.dat.equal.14[[2]])),median(abs(errors.dat.equal.14[[3]])),median(abs(errors.dat.equal.14[[4]])),median(abs(errors.dat.equal.14[[5]])),median(abs(errors.dat.equal.14[[6]])))),1)
all.w14.lower.mean.equal <- round(mean(c(quantile(abs(errors.dat.equal.14[[1]]),0.25),quantile(abs(errors.dat.equal.14[[2]]),0.25),quantile(abs(errors.dat.equal.14[[3]]),0.25),quantile(abs(errors.dat.equal.14[[4]]),0.25),quantile(abs(errors.dat.equal.14[[5]]),0.25),quantile(abs(errors.dat.equal.14[[6]]),0.25))),1)
all.w14.upper.mean.equal <- round(mean(c(quantile(abs(errors.dat.equal.14[[1]]),0.75),quantile(abs(errors.dat.equal.14[[2]]),0.75),quantile(abs(errors.dat.equal.14[[3]]),0.75),quantile(abs(errors.dat.equal.14[[4]]),0.75),quantile(abs(errors.dat.equal.14[[5]]),0.75),quantile(abs(errors.dat.equal.14[[6]]),0.75))),1)

###Figure 1

pdf("figure1.pdf")

par(mfrow=c(3,2))
par(mgp=c(2,0.75,0))
par(mar=c(3,3,3,3))
par(oma=c(2,2,0,0))

for(i in 1:6)
{
    plot(c(1,5),c(15,40),type="n",xlab="Days used in weighting",ylab="MedAPE",axes=FALSE,main=counties.labels[i])
    axis(1,1:5,seq(7,35,7))
    axis(2,las=1)
    box()
    lines(1:5,c(median(abs(errors.dat.equal.7[[i]])),median(abs(errors.dat.equal.14[[i]])),median(abs(errors.dat.equal.21[[i]])),median(abs(errors.dat.equal.28[[i]])),median(abs(errors.dat.equal.35[[i]]))),lty=2)
    points(1:5,c(median(abs(errors.dat.equal.7[[i]])),median(abs(errors.dat.equal.14[[i]])),median(abs(errors.dat.equal.21[[i]])),median(abs(errors.dat.equal.28[[i]])),median(abs(errors.dat.equal.35[[i]]))),pch="E")
    lines(1:5,c(median(abs(errors.dat.unweighted.7[[i]])),median(abs(errors.dat.unweighted.14[[i]])),median(abs(errors.dat.unweighted.21[[i]])),median(abs(errors.dat.unweighted.28[[i]])),median(abs(errors.dat.unweighted.35[[i]]))),col=2,lty=1)
    points(1:5,c(median(abs(errors.dat.unweighted.7[[i]])),median(abs(errors.dat.unweighted.14[[i]])),median(abs(errors.dat.unweighted.21[[i]])),median(abs(errors.dat.unweighted.28[[i]])),median(abs(errors.dat.unweighted.35[[i]]))),pch="U",col=2)
    lines(1:5,c(median(abs(errors.dat.triangle.7[[i]])),median(abs(errors.dat.triangle.14[[i]])),median(abs(errors.dat.triangle.21[[i]])),median(abs(errors.dat.triangle.28[[i]])),median(abs(errors.dat.triangle.35[[i]]))),col=4,lty=3)
    points(1:5,c(median(abs(errors.dat.triangle.7[[i]])),median(abs(errors.dat.triangle.14[[i]])),median(abs(errors.dat.triangle.21[[i]])),median(abs(errors.dat.triangle.28[[i]])),median(abs(errors.dat.triangle.35[[i]]))),pch="T",col=4)
    
}

dev.off()

###Last day for making predictions is 2021-04-28
###Last day for two week predictions of 2021-05-12
###First day for making predictions is 2020-06-14
###First day for two week predictions is 2020-06-28

end.date <- as.Date("2021-05-01")
end.date.numeric <- as.numeric(end.date)
    
start.date <- as.Date("2020-06-28")
start.date.numeric <- as.numeric(start.date)

est.dates <- start.date:end.date
n.est.dates <- length(est.dates)

counties <- c("alameda","contracosta","marin","sanfrancisco","sanmateo","santaclara")
counties.labels <- c("Alameda","Contra Costa","Marin","San Francisco","San Mateo","Santa Clara")
n.counties <- length(counties)

###Read in data from CalCAT

dat <- read.delim("hist_hosp.csv",sep=",",header=TRUE,as.is=TRUE)

###Reduce data to counties of interest

match.dat <- match(dat$county,counties.labels)
dat <- dat[which(!is.na(match.dat)),]

##est_date is date for which prediction is made
##p_date is date when prediction is made

dat$"est_date_numeric" <- as.numeric(as.Date(dat$"est_date"))
dat$"p_date_numeric" <- as.numeric(as.Date(dat$"p_date"))

###Look only at data between our start and end dates for prediction

dat.start.end <- dat[which(dat$"est_date_numeric">=start.date.numeric & dat$"est_date_numeric"<=end.date.numeric),]

###Two week predictions

dat.2wk <- dat.start.end[which((dat.start.end$est_date_numeric-dat.start.end$p_date_numeric)==14),]

###Three week predictions

dat.3wk <- dat.start.end[which((dat.start.end$est_date_numeric-dat.start.end$p_date_numeric)==21),]

###Four week predictions

dat.4wk <- dat.start.end[which((dat.start.end$est_date_numeric-dat.start.end$p_date_numeric)==28),]

###All models

all.models <- sort(unique(dat.start.end$model))

###Drop models called covid and google due to little data

all.common.models <- c("m.proj","can","columbia","jhu","lemma","simple","stanford","ucla","ucsb","ucsd")
n.common.models <- length(all.common.models)

###Make estimate

est.list.2wk <- vector("list",n.counties)
est.list.3wk <- vector("list",n.counties)
est.list.4wk <- vector("list",n.counties)

###Initialize matrix
###Matrix will have rows as dates and models as columns

for(i in 1:n.counties)
{
    mat <- matrix(NA,n.est.dates,n.common.models)
    colnames(mat) <- all.common.models
    rownames(mat) <- est.dates
    est.list.2wk[[i]] <- mat
    est.list.3wk[[i]] <- mat
    est.list.4wk[[i]] <- mat
}

###Fill in with proper values

for(i in 1:n.counties)
{
    new.county <- counties.labels[i]
    dat.2wk.county <- dat.2wk[which(dat.2wk$county==new.county),]
    dat.3wk.county <- dat.3wk[which(dat.3wk$county==new.county),]
    dat.4wk.county <- dat.4wk[which(dat.4wk$county==new.county),]
    for(j in 1:n.common.models)
    {
        new.model <- all.common.models[j]
###Choose data from the count of interest        
        dat.2wk.county.model <- dat.2wk.county[which(dat.2wk.county$model==new.model),]
        dat.3wk.county.model <- dat.3wk.county[which(dat.3wk.county$model==new.model),]
        dat.4wk.county.model <- dat.4wk.county[which(dat.4wk.county$model==new.model),]
###Match the dates where we want predictions to days of predictions
        match.2wk <- match(est.dates,dat.2wk.county.model$est_date_numeric)
        match.3wk <- match(est.dates,dat.3wk.county.model$est_date_numeric)
        match.4wk <- match(est.dates,dat.4wk.county.model$est_date_numeric)
###Take the estimate from the matching day        
        est.list.2wk[[i]][,j] <- dat.2wk.county.model$estimate[match.2wk]
        est.list.3wk[[i]][,j] <- dat.3wk.county.model$estimate[match.3wk]
        est.list.4wk[[i]][,j] <- dat.4wk.county.model$estimate[match.4wk]
    }
}
    
###Add my estimates

est <- vector("list",n.counties)
est.unweighted.w14.p14 <- est
est.unweighted.w14.p21 <- est
est.unweighted.w14.p28 <- est

for(i in 1:n.counties)
{
###est is COVIDNearTerm    
    est[[i]] <- read.delim(paste0("shrinkage_",counties[i],"_hosp_pred.csv"),sep=",",header=TRUE,as.is=TRUE)
###pred_start is first day prediction is made, order in this way    
    est[[i]] <- est[[i]][order(est[[i]]$"pred_startdt"),]
###Don't go past end date
    est[[i]] <- est[[i]][which(as.numeric(as.Date(est[[i]]$Date))<=end.date.numeric),]
###Don't start before start date
    est[[i]] <- est[[i]][which(as.numeric(as.Date(est[[i]]$Date))>=start.date.numeric),]
###Here the prediction is for Date, match is for n-1     
    est.unweighted.w14.p14[[i]] <- est[[i]][which((as.numeric(as.Date(est[[i]]$Date))-as.numeric(as.Date(est[[i]]$"pred_startdt")))==13),]
    est.unweighted.w14.p21[[i]] <- est[[i]][which((as.numeric(as.Date(est[[i]]$Date))-as.numeric(as.Date(est[[i]]$"pred_startdt")))==20),]
    est.unweighted.w14.p28[[i]] <- est[[i]][which((as.numeric(as.Date(est[[i]]$Date))-as.numeric(as.Date(est[[i]]$"pred_startdt")))==27),]
###Choose unweighted data with W=14    
    est.unweighted.w14.p14[[i]] <- est.unweighted.w14.p14[[i]][which(est.unweighted.w14.p14[[i]]$method=="unweighted" & est.unweighted.w14.p14[[i]]$wsize=="14"),]
    est.unweighted.w14.p21[[i]] <- est.unweighted.w14.p21[[i]][which(est.unweighted.w14.p21[[i]]$method=="unweighted" & est.unweighted.w14.p21[[i]]$wsize=="14"),]
    est.unweighted.w14.p28[[i]] <- est.unweighted.w14.p28[[i]][which(est.unweighted.w14.p28[[i]]$method=="unweighted" & est.unweighted.w14.p28[[i]]$wsize=="14"),]
}

###My predictions start on 2020-06-14
###First two week prediction is 2020-06-28
###First three week prediction is 2020-07-05
###First four week prediction is 2020-07-12
###This is why we remove the first 7 days from the calcat predictions for 21 days and the first 14 days from calcat predictions for 28 days

remove.21 <- (1:7)
remove.28 <- (1:14)

###COVIDNearTerm errors

errors.est.unweighted.w14.p14 <- est
errors.est.unweighted.w14.p21 <- est
errors.est.unweighted.w14.p28 <- est

###Calculate errors using hosp.matrix

for(i in 1:n.counties)
{
    errors.est.unweighted.w14.p14[[i]] <- 100*(est.unweighted.w14.p14[[i]]$median-hosp.matrix[,i])/hosp.matrix[,i]
    errors.est.unweighted.w14.p21[[i]] <- 100*(est.unweighted.w14.p21[[i]]$median-hosp.matrix[,i][-remove.21])/hosp.matrix[,i][-remove.21]
    errors.est.unweighted.w14.p28[[i]] <- 100*(est.unweighted.w14.p28[[i]]$median-hosp.matrix[,i][-remove.28])/hosp.matrix[,i][-remove.28]
}

###Errors for calcat methods

errors.est.2wk <- est.list.2wk
errors.est.3wk <- est.list.3wk
errors.est.4wk <- est.list.4wk

for(i in 1:n.counties)
{
    for(j in 1:ncol(est.list.2wk[[i]]))
    {
        errors.est.2wk[[i]][,j] <- 100*(est.list.2wk[[i]][,j]-hosp.matrix[,i])/hosp.matrix[,i]
        errors.est.3wk[[i]][,j] <- 100*(est.list.3wk[[i]][,j]-hosp.matrix[,i])/hosp.matrix[,i]
        errors.est.4wk[[i]][,j] <- 100*(est.list.4wk[[i]][,j]-hosp.matrix[,i])/hosp.matrix[,i]
    }
###Remove first 7 days for 3 week predictions and 14 days for 4 week predictions    
    errors.est.3wk[[i]] <-  errors.est.3wk[[i]][-remove.21,]
    errors.est.4wk[[i]] <-  errors.est.4wk[[i]][-remove.28,]
}

###Calculate median errors
###Row are models, columns are counties

median.percentage.errors.2wk <- matrix(NA,ncol(errors.est.2wk[[1]]),n.counties)
median.percentage.errors.3wk <- matrix(NA,ncol(errors.est.3wk[[1]]),n.counties)
median.percentage.errors.4wk <- matrix(NA,ncol(errors.est.4wk[[1]]),n.counties)
median.percentage.errors.unweighted.w14.p14 <- rep(NA,n.counties)
median.percentage.errors.unweighted.w14.p21 <- rep(NA,n.counties)
median.percentage.errors.unweighted.w14.p28 <- rep(NA,n.counties)

###lower quartile errors

lower.percentage.errors.2wk <- matrix(NA,ncol(errors.est.2wk[[1]]),n.counties)
lower.percentage.errors.3wk <- matrix(NA,ncol(errors.est.3wk[[1]]),n.counties)
lower.percentage.errors.4wk <- matrix(NA,ncol(errors.est.4wk[[1]]),n.counties)
lower.percentage.errors.unweighted.w14.p14 <- rep(NA,n.counties)
lower.percentage.errors.unweighted.w14.p21 <- rep(NA,n.counties)
lower.percentage.errors.unweighted.w14.p28 <- rep(NA,n.counties)

###lower quartile errors

upper.percentage.errors.2wk <- matrix(NA,ncol(errors.est.2wk[[1]]),n.counties)
upper.percentage.errors.3wk <- matrix(NA,ncol(errors.est.3wk[[1]]),n.counties)
upper.percentage.errors.4wk <- matrix(NA,ncol(errors.est.4wk[[1]]),n.counties)
upper.percentage.errors.unweighted.w14.p14 <- rep(NA,n.counties)
upper.percentage.errors.unweighted.w14.p21 <- rep(NA,n.counties)
upper.percentage.errors.unweighted.w14.p28 <- rep(NA,n.counties)

###Just use dates when there is a calcat estimate
for(i in 1:n.counties)
{
    which.2wk.keepers <- which(!is.na(errors.est.2wk[[i]][,1]))
    which.3wk.keepers <- which(!is.na(errors.est.3wk[[i]][,1]))
    which.4wk.keepers <- which(!is.na(errors.est.4wk[[i]][,1]))
###Errors for CalCAT models    
    median.percentage.errors.2wk[,i] <- apply(abs(errors.est.2wk[[i]][which.2wk.keepers,]),2,median,na.rm=TRUE)
    median.percentage.errors.3wk[,i] <- apply(abs(errors.est.3wk[[i]][which.3wk.keepers,]),2,median,na.rm=TRUE)
    median.percentage.errors.4wk[,i] <- apply(abs(errors.est.4wk[[i]][which.4wk.keepers,]),2,median,na.rm=TRUE)
###Errors for COVIDNearTerm    
    median.percentage.errors.unweighted.w14.p14[i] <- median(abs(errors.est.unweighted.w14.p14[[i]][which.2wk.keepers]))
    median.percentage.errors.unweighted.w14.p21[i] <- median(abs(errors.est.unweighted.w14.p21[[i]][which.3wk.keepers]))
    median.percentage.errors.unweighted.w14.p28[i] <- median(abs(errors.est.unweighted.w14.p28[[i]][which.4wk.keepers]))
}

###lower quartile

for(i in 1:n.counties)
{
    which.2wk.keepers <- which(!is.na(errors.est.2wk[[i]][,1]))
    which.3wk.keepers <- which(!is.na(errors.est.3wk[[i]][,1]))
    which.4wk.keepers <- which(!is.na(errors.est.4wk[[i]][,1]))
    lower.percentage.errors.2wk[,i] <- apply(abs(errors.est.2wk[[i]][which.2wk.keepers,]),2,quantile,probs=0.25,na.rm=TRUE)
    lower.percentage.errors.3wk[,i] <- apply(abs(errors.est.3wk[[i]][which.3wk.keepers,]),2,quantile,probs=0.25,na.rm=TRUE)
    lower.percentage.errors.4wk[,i] <- apply(abs(errors.est.4wk[[i]][which.4wk.keepers,]),2,quantile,probs=0.25,na.rm=TRUE)
    lower.percentage.errors.unweighted.w14.p14[i] <- quantile(abs(errors.est.unweighted.w14.p14[[i]][which.2wk.keepers]),probs=0.25)
    lower.percentage.errors.unweighted.w14.p21[i] <- quantile(abs(errors.est.unweighted.w14.p21[[i]][which.3wk.keepers]),probs=0.25)
    lower.percentage.errors.unweighted.w14.p28[i] <- quantile(abs(errors.est.unweighted.w14.p28[[i]][which.4wk.keepers]),probs=0.25)
}

###upper quartile

for(i in 1:n.counties)
{
    which.2wk.keepers <- which(!is.na(errors.est.2wk[[i]][,1]))
    which.3wk.keepers <- which(!is.na(errors.est.3wk[[i]][,1]))
    which.4wk.keepers <- which(!is.na(errors.est.4wk[[i]][,1]))
    upper.percentage.errors.2wk[,i] <- apply(abs(errors.est.2wk[[i]][which.2wk.keepers,]),2,quantile,probs=0.75,na.rm=TRUE)
    upper.percentage.errors.3wk[,i] <- apply(abs(errors.est.3wk[[i]][which.3wk.keepers,]),2,quantile,probs=0.75,na.rm=TRUE)
    upper.percentage.errors.4wk[,i] <- apply(abs(errors.est.4wk[[i]][which.4wk.keepers,]),2,quantile,probs=0.75,na.rm=TRUE)
    upper.percentage.errors.unweighted.w14.p14[i] <- quantile(abs(errors.est.unweighted.w14.p14[[i]][which.2wk.keepers]),probs=0.75)
    upper.percentage.errors.unweighted.w14.p21[i] <- quantile(abs(errors.est.unweighted.w14.p21[[i]][which.3wk.keepers]),probs=0.75)
    upper.percentage.errors.unweighted.w14.p28[i] <- quantile(abs(errors.est.unweighted.w14.p28[[i]][which.4wk.keepers]),probs=0.75)
}

###Add COVIDNearTerm estimates as top row in matrix called final

final.median.percentage.errors.2wk <- rbind.data.frame(median.percentage.errors.unweighted.w14.p14,median.percentage.errors.2wk)
final.median.percentage.errors.3wk <- rbind.data.frame(median.percentage.errors.unweighted.w14.p21,median.percentage.errors.3wk)
final.median.percentage.errors.4wk <- rbind.data.frame(median.percentage.errors.unweighted.w14.p28,median.percentage.errors.4wk)

final.lower.percentage.errors.2wk <- rbind.data.frame(lower.percentage.errors.unweighted.w14.p14,lower.percentage.errors.2wk)
final.lower.percentage.errors.3wk <- rbind.data.frame(lower.percentage.errors.unweighted.w14.p21,lower.percentage.errors.3wk)
final.lower.percentage.errors.4wk <- rbind.data.frame(lower.percentage.errors.unweighted.w14.p28,lower.percentage.errors.4wk)

final.upper.percentage.errors.2wk <- rbind.data.frame(upper.percentage.errors.unweighted.w14.p14,upper.percentage.errors.2wk)
final.upper.percentage.errors.3wk <- rbind.data.frame(upper.percentage.errors.unweighted.w14.p21,upper.percentage.errors.3wk)
final.upper.percentage.errors.4wk <- rbind.data.frame(upper.percentage.errors.unweighted.w14.p28,upper.percentage.errors.4wk)

colnames(final.median.percentage.errors.2wk) <- counties.labels
colnames(final.median.percentage.errors.3wk) <- counties.labels
colnames(final.median.percentage.errors.4wk) <- counties.labels

colnames(final.lower.percentage.errors.2wk) <- counties.labels
colnames(final.lower.percentage.errors.3wk) <- counties.labels
colnames(final.lower.percentage.errors.4wk) <- counties.labels

colnames(final.upper.percentage.errors.2wk) <- counties.labels
colnames(final.upper.percentage.errors.3wk) <- counties.labels
colnames(final.upper.percentage.errors.4wk) <- counties.labels

rownames(final.median.percentage.errors.2wk) <- c("covidnearterm",colnames(errors.est.2wk[[1]]))
rownames(final.median.percentage.errors.3wk) <- c("covidnearterm",colnames(errors.est.3wk[[1]]))
rownames(final.median.percentage.errors.4wk) <- c("covidnearterm",colnames(errors.est.4wk[[1]]))

rownames(final.lower.percentage.errors.2wk) <- c("covidnearterm",colnames(errors.est.2wk[[1]]))
rownames(final.lower.percentage.errors.3wk) <- c("covidnearterm",colnames(errors.est.3wk[[1]]))
rownames(final.lower.percentage.errors.4wk) <- c("covidnearterm",colnames(errors.est.4wk[[1]]))

rownames(final.upper.percentage.errors.2wk) <- c("covidnearterm",colnames(errors.est.2wk[[1]]))
rownames(final.upper.percentage.errors.3wk) <- c("covidnearterm",colnames(errors.est.3wk[[1]]))
rownames(final.upper.percentage.errors.4wk) <- c("covidnearterm",colnames(errors.est.4wk[[1]]))

###Put all three together

final.median.percentage.all <- round(final.median.percentage.errors.2wk)
for(i in 1:nrow(final.median.percentage.all))
{
    for(j in 1:ncol(final.median.percentage.all))
    {
        final.median.percentage.all[i,j] <- paste(round(as.numeric(final.median.percentage.errors.2wk[i,j])),
                                                  round(as.numeric(final.median.percentage.errors.3wk[i,j])),
                                                  round(as.numeric(final.median.percentage.errors.4wk[i,j])),sep=",")
    }
}

write.table(final.median.percentage.all,"table2.txt",sep="\t",row.names=TRUE,col.names=TRUE,quote=FALSE)

final.lower.percentage.all <- round(final.lower.percentage.errors.2wk)
for(i in 1:nrow(final.lower.percentage.all))
{
    for(j in 1:ncol(final.lower.percentage.all))
    {
        final.lower.percentage.all[i,j] <- paste(round(as.numeric(final.lower.percentage.errors.2wk[i,j])),
                                                  round(as.numeric(final.lower.percentage.errors.3wk[i,j])),
                                                  round(as.numeric(final.lower.percentage.errors.4wk[i,j])),sep=",")
    }
}

write.table(final.lower.percentage.all,"final_lower_percentage.all.txt",sep="\t",row.names=TRUE,col.names=TRUE,quote=FALSE)

final.upper.percentage.all <- round(final.upper.percentage.errors.2wk)
for(i in 1:nrow(final.upper.percentage.all))
{
    for(j in 1:ncol(final.upper.percentage.all))
    {
        final.upper.percentage.all[i,j] <- paste(round(as.numeric(final.upper.percentage.errors.2wk[i,j])),
                                                  round(as.numeric(final.upper.percentage.errors.3wk[i,j])),
                                                  round(as.numeric(final.upper.percentage.errors.4wk[i,j])),sep=",")
    }
}

write.table(final.upper.percentage.all,"final_upper_percentage.all.txt",sep="\t",row.names=TRUE,col.names=TRUE,quote=FALSE)

###Figure 2

colVec=c("red","brown","orange","yellow","green","cyan","gray","blue","pink","purple","black","limegreen","salmon","gray","gold","antiquewhite","steelblue","aquamarine","lightcyan","turquoise","hotpink","black")

al <- matrix(as.numeric(unlist(strsplit(final.median.percentage.all$"Alameda",split=","))),ncol=3,byrow=TRUE)
    
cc <- matrix(as.numeric(unlist(strsplit(final.median.percentage.all$"Contra Costa",split=","))),ncol=3,byrow=TRUE)

ma <- matrix(as.numeric(unlist(strsplit(final.median.percentage.all$"Marin",split=","))),ncol=3,byrow=TRUE)

sf <- matrix(as.numeric(unlist(strsplit(final.median.percentage.all$"San Francisco",split=","))),ncol=3,byrow=TRUE)

sm <- matrix(as.numeric(unlist(strsplit(final.median.percentage.all$"San Mateo",split=","))),ncol=3,byrow=TRUE)

sc <- matrix(as.numeric(unlist(strsplit(final.median.percentage.all$"Santa Clara",split=","))),ncol=3,byrow=TRUE)

pdf("figure2.pdf")

par(mgp=c(2,0.75,0))
plot(c(0,1000),c(1,290),type="n",axes=FALSE,ylab="",xlab="Median Absolute Percentage Error",xlim=c(0,100),ylim=c(1,290))
axis(2,c(22,71,120,169,218,267),c("Alameda","Contra Costa","Marin","San Francisco","San Mateo","Santa Clara"),cex.axis=0.75)
axis(1)
box()

counter <- 0
for(i in 1:nrow(al))
{
    new.row <- al[i,]
    counter <- counter+1
    lines(c(0,new.row[1]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[2]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[3]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
}

counter <- counter+5
for(i in 1:nrow(cc))
{
    new.row <- cc[i,]
    counter <- counter+1
    lines(c(0,new.row[1]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[2]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[3]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
}

counter <- counter+5
for(i in 1:nrow(ma))
{
    new.row <- ma[i,]
    counter <- counter+1
    lines(c(0,new.row[1]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[2]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[3]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
}

counter <- counter+5
for(i in 1:nrow(sf))
{
    new.row <- sf[i,]
    counter <- counter+1
    lines(c(0,new.row[1]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[2]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[3]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
}

counter <- counter+5
for(i in 1:nrow(sm))
{
    new.row <- sm[i,]
    counter <- counter+1
    lines(c(0,new.row[1]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[2]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[3]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
}

counter <- counter+5
for(i in 1:nrow(sc))
{
    new.row <- sc[i,]
    counter <- counter+1
    lines(c(0,new.row[1]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[2]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
    lines(c(0,new.row[3]),rep(counter,2),lty=1,lwd=1,col=colVec[i])
    counter <- counter+1
}

dev.off()

###Figure 3

month.cutoffs <- c(4,35,66,96,127,157,188,219,247,278,308)
month.labels <- c(paste0("Jul\n", 20),paste0("Aug\n", 20),paste0("Sep\n", 20),paste0("Oct\n", 20),paste0("Nov\n", 20),paste0("Dec\n", 20),paste0("Jan\n", 21),paste0("Feb\n", 21),paste0("Mar\n", 21),paste0("April\n", 21),paste0("May\n", 21))

pdf("figure3.pdf")

par(mfrow=c(3,2))
par(mgp=c(2,0.75,0))
par(mar=c(3,3,3,3))
par(oma=c(2,2,0,0))

county.maxs <- c(1100,800,150,350,550,1500)

for(i in 1:n.counties)
{
    plot(c(1,n.est.dates),c(0,max(est.unweighted.w14.p14[[i]]$median)),type="n",main=counties.labels[i],axes=FALSE,xlab="",ylab="# Hospitalized",ylim=c(0,county.maxs[i]))
    axis(2,las=1)
    axis(1,month.cutoffs,month.labels,las=1,tck=-0.025,cex.axis=0.8)
    box()
    lines(hosp.matrix[,i],lwd=2)
    lines(est.unweighted.w14.p14[[i]]$median,col=2,lwd=2)
    for(j in 1:1)
    {
        lines(1:n.est.dates,est.list.2wk[[i]][,j],col=rainbow(n.common.models+1)[j+1],lwd=1)
    }
    for(j in 5:6)
    {
        lines(1:n.est.dates,est.list.2wk[[i]][,j],col=rainbow(n.common.models+1)[j+1])
    }
}

dev.off()

###Results from paragraph 7 comparing to to other counties

